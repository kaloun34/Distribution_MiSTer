from downloader.store_migrator import MigrationBase
class MigrationV3(MigrationBase):
    version = 3
    def migrate(self, local_store) -> None:
        ""
        for db in local_store['dbs'].values():
            for zip_id, zip_description in db['zips'].items():
                if 'folders' not in zip_description:
                    continue
                for folder_path, folder_description in zip_description['folders'].items():
                    db['folders'][folder_path] = folder_description
                    db['folders'][folder_path]['zip_id'] = zip_id
                zip_description.pop('folders')
