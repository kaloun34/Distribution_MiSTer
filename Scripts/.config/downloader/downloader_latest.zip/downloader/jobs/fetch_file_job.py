from typing import Optional
from downloader.job_system import Job, JobSystem
from downloader.path_package import PathPackage
class FetchFileJob(Job):
    __slots__ = ('_tags', 'source', 'already_exists', 'pkg', 'db_id', 'after_job')
    type_id: int = JobSystem.get_job_type_id()
    def __init__(self, source: str, already_exists: bool, pkg: PathPackage, db_id: Optional[str], /) -> None:
        self.source = source
        self.already_exists = already_exists
        self.pkg = pkg
        self.db_id = db_id
        self.after_job: Optional[Job] = None
    def backup_job(self) -> Optional[Job]:
        return None if self.after_job is None else self.after_job.backup_job()
