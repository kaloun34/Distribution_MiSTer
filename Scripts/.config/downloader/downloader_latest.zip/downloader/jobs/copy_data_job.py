import io
from typing import Any, Optional, Union
from downloader.job_system import Job, JobSystem
from downloader.jobs.transfer_job import Transferrer
class CopyDataJob(Job, Transferrer):
    __slots__ = ('_tags', 'source', 'description', 'calcs', 'db_id', 'after_job', 'data')
    type_id: int = JobSystem.get_job_type_id()
    def __init__(self, source: str, description: dict[str, Any], calcs: Optional[dict[str, Any]], db_id: Optional[str], /) -> None:
        self.source = source
        self.description = description
        self.calcs = calcs
        self.db_id = db_id
        self.after_job: Optional[Job] = None
        self.data: Optional[io.BytesIO] = None
    def transfer(self) -> Union[str, io.BytesIO]:
        if self.data is None:
            raise Exception('data not ready!')
        return self.data
    def backup_job(self) -> Optional[Job]:
        return None if self.after_job is None else self.after_job.backup_job()
