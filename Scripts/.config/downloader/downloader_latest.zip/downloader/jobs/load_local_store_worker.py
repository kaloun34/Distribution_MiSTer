from downloader.job_system import WorkerResult
from downloader.jobs.load_local_store_job import LoadLocalStoreJob
from downloader.jobs.worker_context import DownloaderWorkerBase
class LoadLocalStoreWorker(DownloaderWorkerBase):
    def job_type_id(self) -> int: return LoadLocalStoreJob.type_id
    def reporter(self): return self._ctx.progress_reporter
    def operate_on(self, job: LoadLocalStoreJob) -> WorkerResult:  # type: ignore[override]
        logger = self._ctx.logger
        logger.bench('LoadLocalStoreWorker start.')
        local_store = self._ctx.local_repository.load_store()
        logger.bench('LoadLocalStoreWorker relocating base paths')
        for relocation_package in self._ctx.base_path_relocator.relocating_base_paths(job.db_pkgs, local_store):
            self._ctx.base_path_relocator.relocate_non_system_files(relocation_package)
            err = self._ctx.local_repository.save_store(local_store)
            if err is not None:
                logger.debug('WARNING! Base path relocation could not be saved in the store!')
                continue
        job.local_store = local_store
        job.full_resync = not self._ctx.local_repository.has_last_successful_run()
        logger.bench('LoadLocalStoreWorker done.')
        return [], None
