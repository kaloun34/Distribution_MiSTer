from downloader.job_system import Job, JobSystem, WorkerResult
from downloader.jobs.worker_context import DownloaderWorker, DownloaderWorkerContext
class AbortJob(Job): type_id: int = JobSystem.get_job_type_id()
class AbortWorker(DownloaderWorker):
    def __init__(self, ctx: DownloaderWorkerContext) -> None:
        self._ctx = ctx
    def job_type_id(self) -> int: return AbortJob.type_id
    def reporter(self): return self._ctx.progress_reporter
    def operate_on(self, job: Job) -> WorkerResult:
        self._ctx.job_ctx.cancel_pending_jobs()
        return [], None
