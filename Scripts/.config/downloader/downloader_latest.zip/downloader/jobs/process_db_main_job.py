from dataclasses import field, dataclass
from typing import Any, Dict, List
from downloader.config import Config, default_config, ConfigDatabaseSection
from downloader.constants import DB_STATE_SIGNATURE_NO_HASH, DB_STATE_SIGNATURE_NO_SIZE
from downloader.db_entity import DbEntity
from downloader.job_system import Job, JobSystem
from downloader.local_store_wrapper import StoreWrapper
@dataclass(eq=False, order=False)
class ProcessDbMainJob(Job):
    type_id: int = field(init=False, default=JobSystem.get_job_type_id())
    db: DbEntity
    store: StoreWrapper
    ini_description: ConfigDatabaseSection
    full_resync: bool
    db_hash: str = field(default=DB_STATE_SIGNATURE_NO_HASH)
    db_size: int = field(default=DB_STATE_SIGNATURE_NO_SIZE)
    def retry_job(self): return None
    ignored_zips: List[str] = field(default_factory=list)
    removed_zips: List[str] = field(default_factory=list)
    config: Config = field(default_factory=default_config)
