from typing import Optional
from downloader.db_utils import DbSectionPackage
from downloader.job_system import Job, JobSystem
from downloader.jobs.abort_worker import AbortJob
from downloader.local_store_wrapper import LocalStoreWrapper
local_store_tag = 'local_store'
class LoadLocalStoreJob(Job):
    type_id: int = JobSystem.get_job_type_id()
    def __init__(self, db_pkgs: list[DbSectionPackage], /) -> None:
        self.db_pkgs = db_pkgs
        self.local_store: Optional[LocalStoreWrapper] = None
        self.full_resync: bool = False
    def backup_job(self) -> Optional[Job]: return AbortJob()
