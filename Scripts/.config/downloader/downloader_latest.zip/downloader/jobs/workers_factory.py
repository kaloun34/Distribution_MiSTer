from typing import List
from downloader.jobs.abort_worker import AbortWorker
from downloader.jobs.copy_data_worker import CopyDataWorker
from downloader.jobs.fetch_data_worker import FetchDataWorker
from downloader.jobs.fetch_file_worker import FetchFileWorker
from downloader.jobs.load_local_store_worker import LoadLocalStoreWorker
from downloader.jobs.open_db_worker import OpenDbWorker
from downloader.jobs.open_zip_contents_worker import OpenZipContentsWorker
from downloader.jobs.open_zip_summary_worker import OpenZipSummaryWorker
from downloader.jobs.process_db_main_worker import ProcessDbMainWorker
from downloader.jobs.wait_db_zips_worker import WaitDbZipsWorker
from downloader.jobs.process_db_index_worker import ProcessDbIndexWorker
from downloader.jobs.process_zip_index_worker import ProcessZipIndexWorker
from downloader.jobs.worker_context import DownloaderWorker, DownloaderWorkerContext
def make_workers(ctx: DownloaderWorkerContext) -> List[DownloaderWorker]:
    return [
        AbortWorker(ctx),
        CopyDataWorker(ctx),
        FetchFileWorker(progress_reporter=ctx.progress_reporter, http_gateway=ctx.http_gateway, file_system=ctx.file_system, timeout=ctx.config['downloader_timeout']),
        FetchDataWorker(ctx, timeout=ctx.config['downloader_timeout']),
        OpenDbWorker(ctx),
        ProcessDbIndexWorker(ctx),
        WaitDbZipsWorker(ctx),
        ProcessDbMainWorker(ctx),
        ProcessZipIndexWorker(ctx),
        LoadLocalStoreWorker(ctx),
        OpenZipSummaryWorker(ctx),
        OpenZipContentsWorker(ctx),
    ]
