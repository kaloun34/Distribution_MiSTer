from downloader.db_entity import check_zip_summary
from downloader.jobs.worker_context import DownloaderWorkerBase
from downloader.jobs.open_zip_summary_job import OpenZipSummaryJob
from downloader.jobs.jobs_factory import make_process_zip_index_job
from downloader.job_system import WorkerResult
class OpenZipSummaryWorker(DownloaderWorkerBase):
    def job_type_id(self) -> int: return OpenZipSummaryJob.type_id
    def reporter(self): return self._ctx.progress_reporter
    def operate_on(self, job: OpenZipSummaryJob) -> WorkerResult:  # type: ignore[override]
        try:
            summary = self._ctx.file_system.load_dict_from_transfer(job.transfer_job.source, job.transfer_job.transfer())  # type: ignore[union-attr]
            check_zip_summary(summary, job.db.db_id, job.zip_id)
            return [make_process_zip_index_job(
                zip_id=job.zip_id,
                zip_description=job.zip_description,
                zip_summary=summary,
                config=job.config,
                db=job.db,
                ini_description=job.ini_description,
                store=job.store,
                full_resync=job.full_resync,
                has_new_zip_summary=True
            )], None
        except Exception as e:
            self._ctx.swallow_error(e)
            return [], e
